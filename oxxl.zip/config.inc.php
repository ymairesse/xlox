<?php

define('INSTALL_DIR', dirname(__FILE__));

// base de données principale
define('NOM', 'root');
define('MDP', '123456');
define('SERVEUR', 'localhost');
define('BASE','oxfamXL');
